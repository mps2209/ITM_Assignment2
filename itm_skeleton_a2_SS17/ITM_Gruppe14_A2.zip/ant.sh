#!/bin/sh

export ANT_HOME=./tools/ant/apache-ant-1.10.0

$ANT_HOME/bin/ant $@